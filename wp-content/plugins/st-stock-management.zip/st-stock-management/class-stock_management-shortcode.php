<?php
/**
 * Stock Management Shortcode 
 * Add this to your plugin file
 */


// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Isolate AJAX calls from other plugins/themes
if (defined('DOING_AJAX') && DOING_AJAX) {
    if (isset($_POST['action']) && strpos($_POST['action'], 'stock_') !== false) {
        // Remove all plugins that might interfere
        remove_all_actions('init');
        remove_all_actions('wp_head');
        remove_all_actions('wp_footer');
        remove_all_actions('admin_init');
        
        // Clear any existing output
        if (ob_get_length()) {
            ob_clean();
        }
    }
}


// Create database table on plugin activation
register_activation_hook(__FILE__, 'create_stock_management_table');

// Register shortcode
add_shortcode('stock_management', 'stock_management_shortcode');

// AJAX handlers for logged-in users
add_action('wp_ajax_add_stock_item', 'ajax_add_stock_item');
add_action('wp_ajax_update_stock_item', 'ajax_update_stock_item');
add_action('wp_ajax_delete_stock_item', 'ajax_delete_stock_item');
add_action('wp_ajax_add_custom_field', 'ajax_add_custom_field');
add_action('wp_ajax_delete_custom_field', 'ajax_delete_custom_field');
add_action('wp_ajax_get_stock_items', 'ajax_get_stock_items');

// AJAX handlers for non-logged-in users (if needed)
add_action('wp_ajax_nopriv_get_stock_items', 'ajax_get_stock_items');

/**
 * Create table if needed (runs on plugin activation)
 */
function create_stock_management_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'stock_management';
    
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        asset_type varchar(100) NOT NULL,
        brand_model varchar(200) NOT NULL,
        serial_number varchar(100) NOT NULL,
        quantity int(11) DEFAULT 1,
        price decimal(10,2) NOT NULL,
        status varchar(50) NOT NULL,
        location varchar(100) NOT NULL,
        date_purchased date NOT NULL,
        warranty_expiry date NULL,
        remarks text NULL,
        custom_fields text NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

function stock_management_shortcode($atts) {
  
   // Ensure jQuery is loaded
    wp_enqueue_script('jquery');
    
    // Add SweetAlert2
    wp_enqueue_script('sweetalert2', 'https://cdn.jsdelivr.net/npm/sweetalert2@11', array(), '11.0.0', true);
    wp_enqueue_style('sweetalert2', 'https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css', array(), '11.0.0');
    
    // ADD DATATABLES
    wp_enqueue_script('datatables', 'https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js', array('jquery'), '1.13.6', true);
    wp_enqueue_style('datatables', 'https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css', array(), '1.13.6');
    
    // Get AJAX URL and nonce
    $ajax_url = admin_url('admin-ajax.php');
    $nonce = wp_create_nonce('stock_management_ajax');
  
    // Ensure jQuery is loaded
    wp_enqueue_script('jquery');
    
    // Add SweetAlert2
    wp_enqueue_script('sweetalert2', 'https://cdn.jsdelivr.net/npm/sweetalert2@11', array(), '11.0.0', true);
    wp_enqueue_style('sweetalert2', 'https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css', array(), '11.0.0');
    
    // Get AJAX URL and nonce
    $ajax_url = admin_url('admin-ajax.php');
    $nonce = wp_create_nonce('stock_management_ajax');
    
    ob_start();
    ?>
    <div id="stock-management-container">
        <style>
          
          /* ADD DATATABLES STYLING */
.dataTables_wrapper {
    background: rgba(255,255,255,0.1);
    padding: 20px;
    border-radius: 10px;
    margin-top: 20px;
}
.dataTables_wrapper table {
    background: transparent !important;
    color: white !important;
}
.dataTables_wrapper th {
    background: rgba(255,215,0,0.2) !important;
    color: #FFD700 !important;
    border-bottom: 2px solid rgba(255,255,255,0.3) !important;
}
.dataTables_wrapper td {
    border-bottom: 1px solid rgba(255,255,255,0.2) !important;
    background: transparent !important;
}
.dataTables_wrapper .dataTables_filter input {
    background: rgba(0,0,0,0.4) !important;
    color: white !important;
    border: 2px solid rgba(255,255,255,0.3) !important;
    border-radius: 5px;
    padding: 5px;
}
.dataTables_wrapper .dataTables_length select {
    background: rgba(0,0,0,0.4) !important;
    color: white !important;
    border: 2px solid rgba(255,255,255,0.3) !important;
    border-radius: 5px;
    padding: 5px;
}
.dataTables_wrapper .dataTables_paginate .paginate_button {
    background: rgba(255,255,255,0.1) !important;
    color: white !important;
    border: 1px solid rgba(255,255,255,0.3) !important;
    border-radius: 5px;
    margin: 2px;
}
.dataTables_wrapper .dataTables_paginate .paginate_button.current {
    background: linear-gradient(45deg, #FFD700, #FFA500) !important;
    color: #333 !important;
}
.dataTables_wrapper .dataTables_paginate .paginate_button:hover {
    background: rgba(255,255,255,0.2) !important;
    color: white !important;
}
            #stock-management-container {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                max-width: 1200px;
                margin: 0 auto;
                padding: 20px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                border-radius: 15px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                color: white;
            }
            .stock-header {
                text-align: center;
                margin-bottom: 30px;
                background: rgba(255,255,255,0.1);
                padding: 20px;
                border-radius: 10px;
                backdrop-filter: blur(10px);
            }
            .stock-header h2 {
                margin: 0;
                font-size: 2.5em;
                background: linear-gradient(45deg, #FFD700, #FFA500);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
            }
            .stock-tabs {
                display: flex;
                margin-bottom: 20px;
                background: rgba(255,255,255,0.1);
                border-radius: 10px;
                padding: 5px;
            }
            .tab-btn {
                flex: 1;
                padding: 12px 20px;
                border: none;
                background: transparent;
                color: white;
                cursor: pointer;
                border-radius: 8px;
                transition: all 0.3s ease;
                font-weight: 600;
            }
            .tab-btn.active {
                background: linear-gradient(45deg, #FFD700, #FFA500);
                color: #333;
                box-shadow: 0 4px 15px rgba(255,215,0,0.4);
            }
            .tab-content {
                display: none;
                background: rgba(255,255,255,0.1);
                padding: 25px;
                border-radius: 10px;
                backdrop-filter: blur(10px);
            }
            .tab-content.active {
                display: block;
            }
            .item-sub-tabs {
                display: flex;
                margin-bottom: 20px;
                background: rgba(255,255,255,0.1);
                border-radius: 10px;
                padding: 5px;
            }
            .item-sub-tab-btn {
                flex: 1;
                padding: 12px 20px;
                border: none;
                background: transparent;
                color: white;
                cursor: pointer;
                border-radius: 8px;
                transition: all 0.3s ease;
                font-weight: 600;
            }
            .item-sub-tab-btn.active {
                background: linear-gradient(45deg, #28a745, #20c997);
                color: white;
                box-shadow: 0 4px 15px rgba(40,167,69,0.4);
            }
            .item-sub-content {
                display: none;
            }
            .item-sub-content.active {
                display: block;
            }
            .form-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
                gap: 20px;
                margin-bottom: 20px;
            }
            .form-group {
                display: flex;
                flex-direction: column;
            }
            .form-group label {
                margin-bottom: 8px;
                font-weight: 600;
                color: #FFD700;
            }
            .form-group input,
            .form-group select,
            .form-group textarea {
                padding: 12px;
                border: 2px solid rgba(255,255,255,0.3);
                border-radius: 8px;
                background-color: rgba(0,0,0,0.4);
                color: #ffffff;
                font-size: 14px;
                line-height: 1.5;
                height: auto;
                transition: all 0.3s ease;
            }
            .form-group input:focus,
            .form-group select:focus,
            .form-group textarea:focus {
                outline: none;
                border-color: #FFD700;
                box-shadow: 0 0 10px rgba(255,215,0,0.3);
            }
            .form-group input::placeholder,
            .form-group textarea::placeholder {
                color: rgba(255,255,255,0.7);
            }
            .btn {
                padding: 12px 25px;
                border: none;
                border-radius: 8px;
                cursor: pointer;
                font-weight: 600;
                transition: all 0.3s ease;
                margin: 5px;
            }
            .btn-primary {
                background: linear-gradient(45deg, #28a745, #20c997);
                color: white;
            }
            .btn-danger {
                background: linear-gradient(45deg, #dc3545, #e74c3c);
                color: white;
            }
            .btn-warning {
                background: linear-gradient(45deg, #ffc107, #ff8c00);
                color: #333;
            }
            .btn-info {
                background: linear-gradient(45deg, #17a2b8, #138496);
                color: white;
            }
            .btn-secondary {
                background: linear-gradient(45deg, #6c757d, #5a6268);
                color: white;
            }
            .btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 5px 15px rgba(0,0,0,0.3);
            }
            .btn:disabled {
                opacity: 0.6;
                cursor: not-allowed;
                transform: none;
            }
            .stock-table {
                width: 100%;
                border-collapse: collapse;
                background: rgba(255,255,255,0.1);
                border-radius: 10px;
                overflow: hidden;
                margin-bottom: 20px;
            }
            .stock-table th, .stock-table td {
                padding: 15px;
                text-align: left;
                border-bottom: 1px solid rgba(255,255,255,0.2);
            }
            .stock-table th {
                background: rgba(255,215,0,0.2);
                font-weight: 600;
                color: #FFD700;
            }
            .stock-table tr:hover {
                background: rgba(255,255,255,0.1);
            }
            .status-active { color: #28a745; font-weight: bold; }
            .status-inactive { color: #dc3545; font-weight: bold; }
            .status-maintenance { color: #ffc107; font-weight: bold; }
            .notification {
                padding: 12px 20px;
                margin: 10px 0;
                border-radius: 8px;
                font-weight: 600;
            }
            .notification.success {
                background: rgba(40, 167, 69, 0.2);
                border: 1px solid #28a745;
                color: #28a745;
            }
            .notification.error {
                background: rgba(220, 53, 69, 0.2);
                border: 1px solid #dc3545;
                color: #dc3545;
            }
            .loading {
                opacity: 0.6;
                pointer-events: none;
            }
            .add-item-section {
                background: rgba(255,255,255,0.1);
                padding: 20px;
                border-radius: 10px;
                margin-top: 20px;
            }
            .custom-fields-container {
                background: rgba(255,255,255,0.05);
                padding: 20px;
                border-radius: 10px;
                margin-top: 20px;
            }
            .edit-form-container {
                background: rgba(255,255,255,0.1);
                padding: 20px;
                border-radius: 10px;
                margin-top: 20px;
            }
            @media (max-width: 768px) {
                .form-grid {
                    grid-template-columns: 1fr;
                }
                .stock-table {
                    font-size: 12px;
                }
                .tab-btn {
                    padding: 8px 12px;
                    font-size: 12px;
                }
                .item-sub-tab-btn {
                    padding: 8px 12px;
                    font-size: 12px;
                }
            }
        </style>

        <div class="stock-header">
            <h2>🏢 Stock Management System</h2>
            <p>Efficiently manage your inventory with advanced features</p>
        </div>

        <div class="stock-tabs">
            <button class="tab-btn active" onclick="showMainTab('item-tab', this)">📦 Item</button>
            <button class="tab-btn" onclick="showMainTab('employee-tab', this)">👨‍💼 Employee</button>
            <button class="tab-btn" onclick="showMainTab('repaire-tab', this)">🔧 Repaire</button>
        </div>

        <!-- Item Tab -->
        <div id="item-tab" class="tab-content active">
            <h3>📦 Item Management</h3>
            
            <!-- Item Sub Tabs -->
            <div class="item-sub-tabs">
                <button class="item-sub-tab-btn active" onclick="showItemSubTab('add-item-tab', this)">➕ Add Item</button>
                
                <button class="item-sub-tab-btn" onclick="showItemSubTab('list-items-tab', this)">📋 List Items</button>
            </div>

            <!-- Add Item Sub Tab -->
            <div id="add-item-tab" class="item-sub-content active">
                <div class="add-item-section">
                    <form id="add-stock-form">
                        <input type="hidden" name="action" value="add_stock_item">
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="asset_type">🏷️ Asset Type *</label>
                                <select id="asset_type" name="asset_type" required>
                                    <option value="">Select Asset Type</option>
                                    <option value="Laptop">Laptop</option>
                                    <option value="Printer">Printer</option>
                                    <option value="Phone">Phone</option>
                                    <option value="Monitor">Monitor</option>
                                    <option value="Tablet">Tablet</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="brand_model">🏭 Brand/Model *</label>
                                <input type="text" id="brand_model" name="brand_model" placeholder="e.g., Dell Inspiron 15" required>
                            </div>
                            <div class="form-group">
                                <label for="serial_number">🔢 Serial Number *</label>
                                <input type="text" id="serial_number" name="serial_number" placeholder="e.g., ABC123456" required>
                            </div>
                            <div class="form-group">
                                <label for="quantity">📦 Quantity</label>
                                <input type="number" id="quantity" name="quantity" value="1" min="1" required disabled>
                            </div>

                            <div class="form-group">
                                <label for="price">💲 Price *</label>
                                <input type="number" id="price" name="price" placeholder="Enter price" step="0.01" required>
                            </div>
                            <div class="form-group">
                                <label for="status">📊 Status *</label>
                                <select id="status" name="status" required>
                                    <option value="">Select Status</option>
                                    <option value="Active">Active</option>
                                    <option value="Inactive">Inactive</option>
                                    <option value="Maintenance">Under Maintenance</option>
                                    <option value="Retired">Retired</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="location">📍 Location *</label>
                                <select id="location" name="location" required>
                                    <option value="">Select Location</option>
                                    <option value="4th Floor">4th Floor</option>
                                    <option value="6th Floor">6th Floor</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="date_purchased">📅 Date Purchased *</label>
                                <input type="date" id="date_purchased" name="date_purchased" required>
                            </div>

                            <div class="form-group">
                                <label for="warranty_expiry">🛡️ Warranty Expiry</label>
                                <input type="date" id="warranty_expiry" name="warranty_expiry">
                            </div>

                            <div class="form-group">
                                <label for="remarks">💭 Remarks</label>
                                <textarea id="remarks" name="remarks" rows="3" placeholder="Any additional notes..."></textarea>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary" id="add_submit_button">✅ Add Stock Item</button>
                        <button type="reset" class="btn btn-secondary">🔄 Reset Form</button>
                    </form>
                </div>
            </div>

            <!-- Edit Item Sub Tab -->
            <div id="edit-item-tab" class="item-sub-content">
                <div class="edit-form-container">
                    <h4>✏️ Edit Existing Item</h4>
                    <form id="edit-stock-form">
                        <input type="hidden" name="action" value="update_stock_item">
                        <input type="hidden" name="item_id" id="edit_item_id" value="">
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="edit_asset_type">🏷️ Asset Type *</label>
                                <select id="edit_asset_type" name="asset_type" required>
                                    <option value="">Select Asset Type</option>
                                    <option value="Laptop">Laptop</option>
                                    <option value="Printer">Printer</option>
                                    <option value="Phone">Phone</option>
                                    <option value="Monitor">Monitor</option>
                                    <option value="Tablet">Tablet</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="edit_brand_model">🏭 Brand/Model *</label>
                                <input type="text" id="edit_brand_model" name="brand_model" placeholder="e.g., Dell Inspiron 15" required>
                            </div>
                            <div class="form-group">
                                <label for="edit_serial_number">🔢 Serial Number *</label>
                                <input type="text" id="edit_serial_number" name="serial_number" placeholder="e.g., ABC123456" required>
                            </div>
                            <div class="form-group">
                                <label for="edit_quantity">📦 Quantity</label>
                                <input type="number" id="edit_quantity" name="quantity" value="1" min="1" required disabled>
                            </div>

                            <div class="form-group">
                                <label for="edit_price">💲 Price *</label>
                                <input type="number" id="edit_price" name="price" placeholder="Enter price" step="0.01" required>
                            </div>
                            <div class="form-group">
                                <label for="edit_status">📊 Status *</label>
                                <select id="edit_status" name="status" required>
                                    <option value="">Select Status</option>
                                    <option value="Active">Active</option>
                                    <option value="Inactive">Inactive</option>
                                    <option value="Maintenance">Under Maintenance</option>
                                    <option value="Retired">Retired</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="edit_location">📍 Location *</label>
                                <select id="edit_location" name="location" required>
                                    <option value="">Select Location</option>
                                    <option value="4th Floor">4th Floor</option>
                                    <option value="6th Floor">6th Floor</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="edit_date_purchased">📅 Date Purchased *</label>
                                <input type="date" id="edit_date_purchased" name="date_purchased" required>
                            </div>

                            <div class="form-group">
                                <label for="edit_warranty_expiry">🛡️ Warranty Expiry</label>
                                <input type="date" id="edit_warranty_expiry" name="warranty_expiry">
                            </div>

                            <div class="form-group">
                                <label for="edit_remarks">💭 Remarks</label>
                                <textarea id="edit_remarks" name="remarks" rows="3" placeholder="Any additional notes..."></textarea>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary" id="edit_submit_button">🔁 Update Stock Item</button>
                        <button type="button" class="btn btn-secondary" onclick="resetEditForm()">↩️ Cancel Edit</button>
                    </form>
                </div>
            </div>

            <!-- List Items Sub Tab -->
            <div id="list-items-tab" class="item-sub-content">
                <div class="items-list-section">
                    <h4>📋 Items List</h4>
                    <div id="stock-items-container">
                        <div style="text-align: center; padding: 40px;">
                            <div style="font-size: 48px; margin-bottom: 20px;">⏳</div>
                            <p>Loading items...</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Employee Tab -->
        <div id="employee-tab" class="tab-content">
            <h3>👨‍💼 Employee Management</h3>
            <div style="background: rgba(255,255,255,0.1); padding: 20px; border-radius: 10px; text-align: center;">
                <p>Employee management functionality will be implemented here.</p>
            </div>
        </div>

        <!-- Repaire Tab -->
        <div id="repaire-tab" class="tab-content">
            <h3>🔧 Repaire Management</h3>
            <div style="background: rgba(255,255,255,0.1); padding: 20px; border-radius: 10px; text-align: center;">
                <p>Repair management functionality will be implemented here.</p>
            </div>
        </div>

        <script>
               // Global variables
    const ajaxUrl = '<?php echo esc_js($ajax_url); ?>';
    const nonce = '<?php echo esc_js($nonce); ?>';
    let stockItems = [];
    let dataTable = null; // ADD DATATABLE VARIABLE

    jQuery(document).ready(function($) {
        // Load stock items on page load
        loadStockItems();
        
        // Handle form submissions
        $('#add-stock-form').on('submit', function(e) {
            e.preventDefault();
            saveStockItem('add');
        });
        
        $('#edit-stock-form').on('submit', function(e) {
            e.preventDefault();
            saveStockItem('edit');
        });
    });
            function showMainTab(tabName, el) {
                // Hide all main tab contents
                document.querySelectorAll('.tab-content').forEach(tab => {
                    tab.classList.remove('active');
                });
                
                // Remove active class from all main tab buttons
                document.querySelectorAll('.tab-btn').forEach(btn => {
                    btn.classList.remove('active');
                });
                
                // Show selected main tab and activate button
                document.getElementById(tabName).classList.add('active');
                el.classList.add('active');
            }

            function showItemSubTab(tabName, el) {
                // Hide all item sub tab contents
                document.querySelectorAll('.item-sub-content').forEach(tab => {
                    tab.classList.remove('active');
                });
                
                // Remove active class from all item sub tab buttons
                document.querySelectorAll('.item-sub-tab-btn').forEach(btn => {
                    btn.classList.remove('active');
                });
                
                // Show selected item sub tab and activate button
                document.getElementById(tabName).classList.add('active');
                el.classList.add('active');
                
                // If switching to list tab, reload items
                if (tabName === 'list-items-tab') {
                    loadStockItems();
                }
            }

            function showSweetAlert(message, type = 'success') {
                const title = type === 'success' ? 'Success!' : 'Error!';
                const icon = type === 'success' ? 'success' : 'error';
                
                Swal.fire({
                    title: title,
                    text: message,
                    icon: icon,
                    confirmButtonColor: type === 'success' ? '#28a745' : '#dc3545',
                    timer: 3000,
                    timerProgressBar: true,
                    showConfirmButton: true
                });
            }

            function setLoading(formType, loading) {
                const submitBtn = document.getElementById(formType + '_submit_button');
                const form = document.getElementById(formType + '-stock-form');
                
                if (loading) {
                    submitBtn.textContent = '⏳ Processing...';
                    submitBtn.disabled = true;
                    form.classList.add('loading');
                } else {
                    if (formType === 'add') {
                        submitBtn.textContent = '✅ Add Stock Item';
                    } else {
                        submitBtn.textContent = '🔁 Update Stock Item';
                    }
                    submitBtn.disabled = false;
                    form.classList.remove('loading');
                }
            }

function loadStockItems() {
        jQuery.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: {
                action: 'get_stock_items',
                nonce: nonce
            },
            beforeSend: function() {
                document.getElementById('stock-items-container').innerHTML = 
                    '<div style="text-align: center; padding: 20px;">Loading items...</div>';
            },
            success: function(response) {
                // Handle potential corrupted JSON response
                let responseData = response;
                if (typeof response === 'string') {
                    const jsonMatch = response.match(/\{.*\}/s);
                    if (jsonMatch) {
                        try {
                            responseData = JSON.parse(jsonMatch[0]);
                        } catch (e) {
                            showSweetAlert('Data format error', 'error');
                            return;
                        }
                    } else {
                        showSweetAlert('Invalid response format', 'error');
                        return;
                    }
                }
                
                if (responseData.success) {
                    document.getElementById('stock-items-container').innerHTML = responseData.data.html;
                    stockItems = responseData.data.items || [];
                    
                    // INITIALIZE DATATABLE
                    initializeDataTable();
                } else {
                    showSweetAlert('Error: ' + responseData.data, 'error');
                }
            },
            error: function(xhr, status, error) {
                // Try to extract JSON from corrupted response
                const responseText = xhr.responseText;
                const jsonMatch = responseText.match(/\{.*\}/s);
                if (jsonMatch) {
                    try {
                        const responseData = JSON.parse(jsonMatch[0]);
                        if (responseData.success) {
                            document.getElementById('stock-items-container').innerHTML = responseData.data.html;
                            stockItems = responseData.data.items || [];
                            initializeDataTable(); // INITIALIZE DATATABLE
                            return;
                        }
                    } catch (e) {
                        // Continue with error display
                    }
                }
                showSweetAlert('Failed to load items. Please try again.', 'error');
            }
        });
    }

    // ADD THIS NEW FUNCTION FOR DATATABLE INITIALIZATION
    function initializeDataTable() {
        if (dataTable) {
            dataTable.destroy();
        }
        
        dataTable = jQuery('.stock-table').DataTable({
            "pageLength": 10,
            "lengthMenu": [5, 10, 25, 50],
            "order": [[0, "desc"]],
            "language": {
                "search": "Search:",
                "lengthMenu": "Show _MENU_ entries",
                "info": "Showing _START_ to _END_ of _TOTAL_ entries",
                "infoEmpty": "Showing 0 to 0 of 0 entries",
                "infoFiltered": "(filtered from _MAX_ total entries)",
                "zeroRecords": "No matching records found",
                "paginate": {
                    "first": "First",
                    "last": "Last",
                    "next": "Next →",
                    "previous": "← Previous"
                }
            },
            "responsive": true
        });
    }

            function saveStockItem(formType) {
                const form = document.getElementById(formType + '-stock-form');
                const formData = new FormData(form);
                formData.append('nonce', nonce);

                setLoading(formType, true);

                jQuery.ajax({
                    url: ajaxUrl,
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        setLoading(formType, false);
                        
                        // Handle potential corrupted JSON response
                        let responseData = response;
                        if (typeof response === 'string') {
                            const jsonMatch = response.match(/\{.*\}/s);
                            if (jsonMatch) {
                                try {
                                    responseData = JSON.parse(jsonMatch[0]);
                                } catch (e) {
                                    showSweetAlert('Response format error', 'error');
                                    return;
                                }
                            } else {
                                showSweetAlert('Invalid response format', 'error');
                                return;
                            }
                        }
                        
                        if (responseData.success) {
                            showSweetAlert(responseData.data, 'success');
                            form.reset();
                            loadStockItems();
                            
                            // If editing was successful, switch to list tab
                            if (formType === 'edit') {
                                showItemSubTab('list-items-tab', document.querySelector('.item-sub-tab-btn:nth-child(3)'));
                                resetEditForm();
                            }
                        } else {
                            showSweetAlert('Error: ' + responseData.data, 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        setLoading(formType, false);
                        // Try to extract JSON from corrupted response
                        const responseText = xhr.responseText;
                        const jsonMatch = responseText.match(/\{.*\}/s);
                        if (jsonMatch) {
                            try {
                                const responseData = JSON.parse(jsonMatch[0]);
                                if (responseData.success) {
                                    showSweetAlert(responseData.data, 'success');
                                    form.reset();
                                    loadStockItems();
                                    if (formType === 'edit') {
                                        showItemSubTab('list-items-tab', document.querySelector('.item-sub-tab-btn:nth-child(3)'));
                                        resetEditForm();
                                    }
                                    return;
                                } else {
                                    showSweetAlert('Error: ' + responseData.data, 'error');
                                    return;
                                }
                            } catch (e) {
                                // Continue with generic error
                            }
                        }
                        showSweetAlert('Server error. Please try again.', 'error');
                    }
                });
            }

            function editItem(id) {
                const item = stockItems.find(item => parseInt(item.id) === parseInt(id));
                if (!item) {
                    showSweetAlert('Item not found.', 'error');
                    return;
                }

                // Switch to edit tab
                showItemSubTab('edit-item-tab', document.querySelector('.item-sub-tab-btn:nth-child(2)'));

                // Populate edit form fields
                document.getElementById('edit_asset_type').value = item.asset_type || '';
                document.getElementById('edit_brand_model').value = item.brand_model || '';
                document.getElementById('edit_serial_number').value = item.serial_number || '';
                document.getElementById('edit_quantity').value = item.quantity || '1';
                document.getElementById('edit_price').value = item.price || '';
                document.getElementById('edit_status').value = item.status || '';
                document.getElementById('edit_location').value = item.location || '';
                document.getElementById('edit_date_purchased').value = item.date_purchased || '';
                document.getElementById('edit_warranty_expiry').value = item.warranty_expiry || '';
                document.getElementById('edit_remarks').value = item.remarks || '';
                document.getElementById('edit_item_id').value = item.id;
            }

            function resetEditForm() {
                document.getElementById('edit-stock-form').reset();
                document.getElementById('edit_item_id').value = '';
                // Switch back to list tab
                showItemSubTab('list-items-tab', document.querySelector('.item-sub-tab-btn:nth-child(3)'));
            }

            function deleteItem(id) {
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#dc3545',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        jQuery.ajax({
                            url: ajaxUrl,
                            type: 'POST',
                            data: {
                                action: 'delete_stock_item',
                                item_id: id,
                                nonce: nonce
                            },
                            success: function(response) {
                                // Handle potential corrupted JSON response
                                let responseData = response;
                                if (typeof response === 'string') {
                                    const jsonMatch = response.match(/\{.*\}/s);
                                    if (jsonMatch) {
                                        try {
                                            responseData = JSON.parse(jsonMatch[0]);
                                        } catch (e) {
                                            showSweetAlert('Response format error', 'error');
                                            return;
                                        }
                                    } else {
                                        showSweetAlert('Invalid response format', 'error');
                                        return;
                                    }
                                }
                                
                                if (responseData.success) {
                                    showSweetAlert(responseData.data, 'success');
                                    loadStockItems();
                                } else {
                                    showSweetAlert('Error: ' + responseData.data, 'error');
                                }
                            },
                            error: function(xhr, status, error) {
                                // Try to extract JSON from corrupted response
                                const responseText = xhr.responseText;
                                const jsonMatch = responseText.match(/\{.*\}/s);
                                if (jsonMatch) {
                                    try {
                                        const responseData = JSON.parse(jsonMatch[0]);
                                        if (responseData.success) {
                                            showSweetAlert(responseData.data, 'success');
                                            loadStockItems();
                                            return;
                                        } else {
                                            showSweetAlert('Error: ' + responseData.data, 'error');
                                            return;
                                        }
                                    } catch (e) {
                                        // Continue with generic error
                                    }
                                }
                                showSweetAlert('Server error. Please try again.', 'error');
                            }
                        });
                    }
                });
            }
        </script>
    </div>
    <?php
    return ob_get_clean();
}

// AJAX function to get stock items
function ajax_get_stock_items() {
    // Complete isolation for AJAX calls
    $is_ajax = defined('DOING_AJAX') && DOING_AJAX;
    if ($is_ajax && isset($_POST['action']) && $_POST['action'] === 'get_stock_items') {
        // Remove all output buffers
        while (ob_get_level()) {
            ob_end_clean();
        }
        
        // Set headers first
        header('Content-Type: application/json');
        header('Cache-Control: no-cache, must-revalidate');
    }
    
    try {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'stock_management_ajax')) {
            echo json_encode(array('success' => false, 'data' => 'Security verification failed'));
            exit;
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'stock_management';

        // Check if table exists, create if not
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            create_stock_management_table();
        }

        $results = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC");

        if (empty($results)) {
            echo json_encode(array(
                'success' => true,
                'data' => array(
                    'html' => '<p>No stock items found. Add some items to get started!</p>',
                    'items' => array()
                )
            ));
            exit;
        }

       $html = '<table class="stock-table" style="width:100%">'; // ADD style="width:100%"
    $html .= '<thead><tr>';
    $html .= '<th>ID</th>'; // ADD ID COLUMN
    $html .= '<th>Asset Type</th><th>Brand/Model</th><th>Serial Number</th>';
    $html .= '<th>Quantity</th><th>Price</th>';
    $html .= '<th>Status</th><th>Location</th>';
    $html .= '<th>Date Purchased</th>'; // ADD DATE COLUMN
    $html .= '<th>Actions</th>';
    $html .= '</tr></thead><tbody>';

    foreach ($results as $row) {
        $status_class = 'status-' . strtolower($row->status);

        $html .= '<tr>';
        $html .= '<td>' . intval($row->id) . '</td>'; // ADD ID CELL
        $html .= '<td>' . esc_html($row->asset_type) . '</td>';
        $html .= '<td>' . esc_html($row->brand_model) . '</td>';
        $html .= '<td>' . esc_html($row->serial_number) . '</td>';
        $html .= '<td>' . intval($row->quantity) . '</td>';
        $html .= '<td>$' . number_format((float) $row->price, 2) . '</td>';
        $html .= '<td class="' . esc_attr($status_class) . '">' . esc_html($row->status) . '</td>';
        $html .= '<td>' . esc_html($row->location) . '</td>';
        $html .= '<td>' . esc_html($row->date_purchased) . '</td>'; // ADD DATE CELL
        $html .= '<td>';
        $html .= '<button class="btn btn-warning" onclick="editItem(' . intval($row->id) . ')">✏️ Edit</button> ';
        $html .= '<button class="btn btn-danger" onclick="deleteItem(' . intval($row->id) . ')">🗑️ Delete</button>';
        $html .= '</td>';
        $html .= '</tr>';
    }

    $html .= '</tbody></table>';

        echo json_encode(array(
            'success' => true,
            'data' => array(
                'html' => $html,
                'items' => $results
            )
        ));
        exit;

    } catch (Exception $e) {
        echo json_encode(array(
            'success' => false,
            'data' => 'Database error: ' . $e->getMessage()
        ));
        exit;
    }
}

// AJAX function to add stock item
function ajax_add_stock_item() {
    // Clear any previous output and set headers
    while (ob_get_level()) { ob_end_clean(); }
    header('Content-Type: application/json');
    
    try {
        if (!wp_verify_nonce($_POST['nonce'], 'stock_management_ajax')) {
            echo json_encode(array('success' => false, 'data' => 'Security verification failed'));
            exit;
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'stock_management';

        $result = $wpdb->insert(
            $table_name,
            array(
                'asset_type' => sanitize_text_field($_POST['asset_type']),
                'brand_model' => sanitize_text_field($_POST['brand_model']),
                'serial_number' => sanitize_text_field($_POST['serial_number']),
                'quantity' => intval($_POST['quantity']),
                'price' => floatval($_POST['price']),
                'status' => sanitize_text_field($_POST['status']),
                'location' => sanitize_text_field($_POST['location']),
                'date_purchased' => sanitize_text_field($_POST['date_purchased']),
                'warranty_expiry' => sanitize_text_field($_POST['warranty_expiry']),
                'remarks' => sanitize_textarea_field($_POST['remarks']),
                'custom_fields' => ''
            )
        );

        if ($result) {
            echo json_encode(array('success' => true, 'data' => 'Stock item added successfully!'));
        } else {
            echo json_encode(array('success' => false, 'data' => 'Database error: ' . $wpdb->last_error));
        }
        exit;
    } catch (Exception $e) {
        echo json_encode(array('success' => false, 'data' => 'Server error: ' . $e->getMessage()));
        exit;
    }
}

// AJAX function to update stock item
function ajax_update_stock_item() {
    // Clear any previous output and set headers
    while (ob_get_level()) { ob_end_clean(); }
    header('Content-Type: application/json');
    
    try {
        if (!wp_verify_nonce($_POST['nonce'], 'stock_management_ajax')) {
            echo json_encode(array('success' => false, 'data' => 'Security verification failed'));
            exit;
        }

        if (!isset($_POST['item_id'])) {
            echo json_encode(array('success' => false, 'data' => 'Missing item ID'));
            exit;
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'stock_management';

        $result = $wpdb->update(
            $table_name,
            array(
                'asset_type' => sanitize_text_field($_POST['asset_type']),
                'brand_model' => sanitize_text_field($_POST['brand_model']),
                'serial_number' => sanitize_text_field($_POST['serial_number']),
                'quantity' => intval($_POST['quantity']),
                'price' => floatval($_POST['price']),
                'status' => sanitize_text_field($_POST['status']),
                'location' => sanitize_text_field($_POST['location']),
                'date_purchased' => sanitize_text_field($_POST['date_purchased']),
                'warranty_expiry' => sanitize_text_field($_POST['warranty_expiry']),
                'remarks' => sanitize_textarea_field($_POST['remarks'])
            ),
            array('id' => intval($_POST['item_id']))
        );

        if ($result !== false) {
            echo json_encode(array('success' => true, 'data' => 'Stock item updated successfully!'));
        } else {
            echo json_encode(array('success' => false, 'data' => 'Database error: ' . $wpdb->last_error));
        }
        exit;
    } catch (Exception $e) {
        echo json_encode(array('success' => false, 'data' => 'Server error: ' . $e->getMessage()));
        exit;
    }
}

// AJAX function to delete stock item
function ajax_delete_stock_item() {
    // Clear any previous output and set headers
    while (ob_get_level()) { ob_end_clean(); }
    header('Content-Type: application/json');
    
    try {
        if (!wp_verify_nonce($_POST['nonce'], 'stock_management_ajax')) {
            echo json_encode(array('success' => false, 'data' => 'Security verification failed'));
            exit;
        }

        if (!isset($_POST['item_id'])) {
            echo json_encode(array('success' => false, 'data' => 'Missing item ID'));
            exit;
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'stock_management';

        $result = $wpdb->delete(
            $table_name,
            array('id' => intval($_POST['item_id']))
        );

        if ($result) {
            echo json_encode(array('success' => true, 'data' => 'Stock item deleted successfully!'));
        } else {
            echo json_encode(array('success' => false, 'data' => 'Database error: ' . $wpdb->last_error));
        }
        exit;
    } catch (Exception $e) {
        echo json_encode(array('success' => false, 'data' => 'Server error: ' . $e->getMessage()));
        exit;
    }
}

// Simplified AJAX functions for custom fields
function ajax_add_custom_field() {
    if (ob_get_length()) ob_clean();
    header('Content-Type: application/json');
    echo json_encode(array('success' => false, 'data' => 'Custom fields feature coming soon'));
    exit;
}

function ajax_delete_custom_field() {
    if (ob_get_length()) ob_clean();
    header('Content-Type: application/json');
    echo json_encode(array('success' => false, 'data' => 'Custom fields feature coming soon'));
    exit;
}